// Get elements by ID
const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');
const message = document.getElementById('message');

// Messages when "No" is clicked
const noMessages = [
    "Are you sure? 😢",
    "Are you mad? 🤔",
    "It's okay, I can wait... 🥺",
    "I will buy you chocolate 🍫",
    "I will buy you saree 👗",
    "I will buy you bodycon 👗",
    "I will take you out for dinner 🍽️",
    "I will talk to your parents 😅",
    "I will marry you 💍",
    "Let's go for a trip ✈️",
    "Honeymoon? 😜",
    "Please say yes 🙏",
    "Please... 🥺",
    "Pleaseee... 😩",
    "Pleaseeee... 😭",
    "Pretty please? 😇",
    "I will call your dad if you click no... 😂",
    "Last chance... 😳",
    "Don't be heartless 💔",
    "Click Yes... you know you want to! 😉"
];

let index = 0;

// Yes Button Event
yesBtn.addEventListener("click", () => {
    message.innerText = "I know you love me so much, my Valentine! 💝";
    noBtn.style.display = "none";
    yesBtn.style.display = "none";
});

// No Button Event
noBtn.addEventListener("click", () => {
    // Change message each time
    if (index < noMessages.length) {
        message.innerText = noMessages[index];
        index++;
    } else {
        message.innerText = "I will wait... forever if I have to... 😭";
    }

    // Make the No button move randomly
    const x = Math.floor(Math.random() * (window.innerWidth - noBtn.clientWidth));
    const y = Math.floor(Math.random() * (window.innerHeight - noBtn.clientHeight));

    noBtn.style.position = "absolute";
    noBtn.style.left = `${x}px`;
    noBtn.style.top = `${y}px`;
});

// Function to create floating toys and teddies
function createFloatingToy() {
    const toy = document.createElement('div');
    toy.classList.add('floating-toy');

    // Randomly select emoji for toy or teddy
    const toys = ['🧸', '🎈', '🎁', '🎀', '💖'];
    toy.innerText = toys[Math.floor(Math.random() * toys.length)];

    // Random position and size
    toy.style.left = Math.random() * 100 + 'vw';
    toy.style.animationDuration = 5 + Math.random() * 10 + 's';
    toy.style.fontSize = 30 + Math.random() * 50 + 'px';

    document.body.appendChild(toy);

    // Remove toy after animation ends
    setTimeout(() => {
        toy.remove();
    }, 12000);
}

// Continuously create floating toys
setInterval(createFloatingToy, 1000);